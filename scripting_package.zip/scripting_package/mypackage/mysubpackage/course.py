class Course:
    
    uniCollege = "Thomas More"
    credits = 6
      
    #def __init__(self, name=False):
    #    if name == False:
    #        print("The course has been created!")
    #    else:
    #        print(f"The course {name} has been created!")
    
    def __init__(self, name, teacher):
        self.name = name
        self.teacher = teacher
        
        
    def studying(self):
        print(f"Boohoo, I'm studying {self.name}")
        
    def frustrated(self, name):
        print(f"RRRRRRRRRR {self.name} really sucks. I, {name}, could be doing something else.")
