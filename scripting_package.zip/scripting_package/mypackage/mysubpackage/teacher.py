class Teacher():

    def __init__(self):
        pass